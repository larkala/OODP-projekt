package model;

public class Student {
	private String name;
	private int persnbr;
	private String email;
	private String adress;
	
	public Student (String name, String email, String adress, int persnr) {
		this.name = name;
		this.email = email;
		this.adress = adress;
		this.persnbr = persnr;
	}

	public String getName() {return name;}
	public int getPersnbr() {return persnbr;}
	public String getEmail() {return email;}
	public String getAdress() {return adress;}
		
}
