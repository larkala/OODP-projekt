package dao;

import model.Course;

public interface CourseDAO {
	
	public void saveCourse(Course course);
	public Course loadCourse(String courseCode);
	
}
