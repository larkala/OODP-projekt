package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import control.CourseManager;

public class GUI extends JFrame{
	
	CourseManager manager = new CourseManager();
	
	JPanel addPanel, viewPanel;
	JButton saveCourseButton = new JButton("Spara");
	Font rubrik = new Font(Font.SANS_SERIF, Font.BOLD, 22);
	JLabel titel = new JLabel("L�gg till kurser");
	CoursePanel c;
	
	public GUI(){
		setLayout(new GridLayout(2, 1));
		
		createComponents();
		
		setBounds(500,500,500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void createComponents() {
		addPanel = new JPanel();
		viewPanel = new JPanel();
		viewPanel.setBackground(Color.BLUE);
		
		c = new CoursePanel();
		
		addPanel.setLayout(new BorderLayout());
		addPanel.add(c, BorderLayout.CENTER);
		addPanel.add(titel, BorderLayout.NORTH);
		addPanel.add(saveCourseButton, BorderLayout.SOUTH);
		
		ActionListener listener = new AddListener();
		saveCourseButton.addActionListener(listener);
		
		titel.setFont(rubrik);
		
		add(addPanel);
		add(viewPanel);
	}
	
	private class AddListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			manager.callAdd(c.getCourseCodeGUI(),c.getCourseNameGUI(), c.getApplicationCodeGUI(),c.getCoursePointsGUI(),c.getCourseSpeedGUI(), c.getCourseGradeGUI(), c.getLastApplicationDateGUI(), c.getScheduleGUI(), c.getCoursePlanGUI());
			
		}
		
	}
	
	public static void main(String[] args) {
		GUI g = new GUI();
	}
}
