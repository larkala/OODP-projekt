package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class dbConManagerSingleton {
	
	private static final String DB_NAME = "";
	private static final String USER = "";
	private static final String PASSWORD = "";
	private static final String CONNECTION_URL = "" + DB_NAME;
	
	private Connection connection = null;
	private Statement statement = null; 
	private ResultSet resultset = null;
	private static dbConManagerSingleton instance = null;
	
	public static dbConManagerSingleton getInstance() {
		if(instance == null) {
			instance = new dbConManagerSingleton();
		}
		return instance;
	}
	
	private Connection getConnection() {
		try {
			connection = DriverManager.getConnection(CONNECTION_URL, USER, PASSWORD);
			System.out.println("Connected to the PostgreSQL!");
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return connection;
	}
	
	private Statement getStatement(Connection connection) {
		try {
			statement = connection.createStatement();
		}catch(SQLException e) {
			System.out.println("Couldn't create statement!");
			System.out.println(e.getMessage());
		}
		return statement;
	}
	
	
	public ResultSet executeQuery(String sqlString) throws SQLException {
		return this.getStatement(this.getConnection()).executeQuery(sqlString);
	}
	
	public PreparedStatement preparedStatement(String statementString) throws SQLException{
		return this.getConnection().prepareStatement(statementString);
	}
	
	public void close() {
		try {
			if(connection != null)
				connection.close();
			if(statement != null)
				statement.close();
			System.out.println("The DB connection closed");
		} catch(SQLException e) {
			System.out.println("Couldn't close the connection or the statement!");
			System.out.println(e.getMessage());
		}
	}
	
	

}
