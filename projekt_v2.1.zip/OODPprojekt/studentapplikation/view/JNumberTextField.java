package view;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JTextField;

public class JNumberTextField extends JTextField {

	public JNumberTextField() {
		this.setText("");
		this.addKeyListener(new Listener());
	}

	class Listener implements KeyListener {

		@Override
		public void keyTyped(KeyEvent e) {
			char key = e.getKeyChar();

			if (!((key >= '0') && (key <= '9') || (key == KeyEvent.VK_BACK_SPACE) || (key == KeyEvent.VK_DELETE))) {
				e.consume();
			}
		}

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub

		}

	}

}
