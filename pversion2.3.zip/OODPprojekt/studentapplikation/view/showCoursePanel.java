package view;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class showCoursePanel extends JPanel{
	
	private JLabel rubrikP1;
	private JPanel mainPanel, panel2, panel3, panel4;
	private JRadioButton radio1, radio2;
	private JTextField t1;
	private JTextArea text1;
	private JButton knapp1;
	private ButtonGroup group;
	
	public showCoursePanel() {
		
		ActionListener listener = new AddListener();

		rubrikP1 = new JLabel("Visa kurs");
		/////PANEL2//////////
		panel2 = new JPanel();
		group = new ButtonGroup();
		radio1 = new JRadioButton("Hitta en kurs");
		radio1.addActionListener(listener);
		radio2 = new JRadioButton("Hitta kurser");
		radio2.addActionListener(listener);
		group.add(radio1);
		group.add(radio2);
		panel2.setLayout(new FlowLayout());
		panel2.add(radio1);
		panel2.add(radio2);
		
		/////PANEL3//////////
		text1 = new JTextArea("Kurskod: ");
		knapp1 = new JButton("Hitta");
		t1 = new JTextField(7);
		panel3 = new JPanel();
		panel3.add(text1);
		panel3.add(t1);
		panel3.add(knapp1);
		
		///////PANEL4//////////
		panel4 = new JPanel(new BorderLayout(1, 1));
		panel4 = new JPanel();
		panel4.setSize(1000, 1000);
		panel4.setBackground(Color.WHITE);
		
		
	
		//////////////////////////
		mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(4, 1));
		mainPanel.add(rubrikP1);
		mainPanel.add(panel2);
		add(mainPanel);	
		
	}
	public class AddListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if(radio1.isSelected()) {	
				mainPanel.add(panel3);
				mainPanel.remove(panel4);
			} else if(radio2.isSelected()){
				mainPanel.remove(panel3);
				mainPanel.add(panel4);
			}
			revalidate();
			repaint();
			
		}
		  
	 }
	
}
