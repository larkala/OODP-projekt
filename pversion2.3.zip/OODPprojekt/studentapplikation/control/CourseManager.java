package control;

import java.net.URI;
import java.util.Date;

import model.CourseList;

public class CourseManager {

	CourseList model = new CourseList();
	
	public void callAdd(String courseCode, String name, String applicationCode, String uniPoints, String studySpeed, String courseGrade, Date lastAppDate, URI schema, URI coursePlan){
		model.addCourse(courseCode, name, applicationCode, uniPoints, studySpeed, courseGrade, lastAppDate, schema, coursePlan);
	}
	
}
