package view;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class GUI extends JFrame{
	
	JPanel addPanel, viewPanel;
	
	public GUI(){
		setLayout(new GridLayout(2, 1));
		
		createComponents();
		
		setBounds(500,500,500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void createComponents() {
		addPanel = new JPanel();
		viewPanel = new JPanel();
		addPanel.setBackground(Color.BLACK);
		viewPanel.setBackground(Color.BLUE);
		
		addPanel.setLayout(new GridLayout(1, 1));
		addPanel.add(new CoursePanel());
		
		add(addPanel);
		add(viewPanel);
	}
	
	public static void main(String[] args) {
		GUI g = new GUI();
	}
}
