package model;

import java.net.URL;

public class Course {

	private String courseCode;
	private String courseName;
	private String applicationCode;
	private String courseSpeed;
	private double coursePoints;
	private String lastApplicationDate;
	private String coursePlan;
	private URL schedule;
	private char courseGrade;
	
	public Course(String courseCode, String name, String applicationCode, String studySpeed, double uniPoints) {
		this.courseName = name;
		this.courseCode = courseCode;
		this.applicationCode = applicationCode;
		this.courseSpeed = studySpeed;
		this.coursePoints = uniPoints;
	}

	
	//getters
	public String getLastApplicationDate() {return lastApplicationDate;}
	public String getCoursePlan() {return coursePlan;}	
	public URL getSchedule() {return schedule;}
	public String getCourseCode() {return courseCode;}
	public String getApplicationCode() {return applicationCode;}
	public String getStudySpeed() {return courseSpeed;}
	public double getUniversityPoints() {return coursePoints;}
	public char getCourseGrade() {return courseGrade;}
	public String getCourseName() {return courseName;}

	//setters
	public void setCoursePlan(String coursePlan) {this.coursePlan = coursePlan;}
	public void setSchedule(URL schedule) {this.schedule = schedule;}
	public void setCourseGrade(char grade) {this.courseGrade = grade;}
	public void setLastApplicationDate(String lastApplicationDate) {this.lastApplicationDate = lastApplicationDate;}

}
