package model;

public class Exam {

	private String studentName;
	private String courseName;
	private String date;
	private String room;
	private String deadlineForRegister;
	private char gradeOfExam;

	////////////// SETTERS////////////////////////////////////////////
	public void setStudentName(String studentName) {this.studentName = studentName;}
	public void setCourseName(String courseName) {this.courseName = courseName;}
	public void setDate(String date) {this.date = date;}
	public void setRoom(String room) {this.room = room;}
	public void setDeadlineForRegister(String deadlineForRegister) {this.deadlineForRegister = deadlineForRegister;}
	public void setGradeOfExam(char gradeOfExam) {this.gradeOfExam = gradeOfExam;}

	////////////// GETTERS////////////////////////////////////////////
	public String getStudentName() {return studentName;}
	public String getCourseName() {return courseName;}
	public String getDate() {return date;}
	public String getRoom() {return room;}
	public String getDeadlineForRegister() {return deadlineForRegister;}
	public char getGradeOfExam() {return gradeOfExam;}

}
