package model;

public class Assignment implements CourseMoment{
	private int assignmentGroup;
	private String nameOfAssignment;
	private int deadlineAssignment;
	private String gradeOfAssignment;

	////////////// SETTERS////////////////////////////////////////////
	public void setAssignmentGroup(int assignmentGroup) {this.assignmentGroup = assignmentGroup;}
	public void setNameOfAssignment(String nameOfAssignment) {this.nameOfAssignment = nameOfAssignment;}
	public void setDeadlineAssignment(int deadlineAssignment) {this.deadlineAssignment = deadlineAssignment;}
	public void setGradeOfAssignment(String gradeOfAssignment) {this.gradeOfAssignment = gradeOfAssignment;}
	
	////////////// GETTERS////////////////////////////////////////////
	public int getAssignmentGroup() {return assignmentGroup;}
	public String getNameOfAssignment() {return nameOfAssignment;}
	public int getDeadlineAssignment() {return deadlineAssignment;}
	public String getGradeOfAssignment() {return gradeOfAssignment;}

}
