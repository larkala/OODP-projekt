package dao;


import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import db.DbConManagerSingleton;
import model.Course;

public class CourseDAO implements IDao{
	
	DbConManagerSingleton dbConManagerSingleton = null;
	
	public CourseDAO() {
		dbConManagerSingleton = DbConManagerSingleton.getInstance();
	}

	@Override
	public void saveCourse(Course course) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
		preparedStatement = dbConManagerSingleton.preparedStatement("INSERT INTO Course(course_code, course_name, "
				+ "application_code, course_speed, course_points, last_application_date, course_plan, schedule)");
		preparedStatement.setString(0, course.getCourseCode());
		preparedStatement.setString(1, course.getCourseName());
		preparedStatement.setString(2, course.getApplicationCode());
		preparedStatement.setString(3, course.getCourseSpeed());
		preparedStatement.setString(4, course.getCoursePoints());
		preparedStatement.setString(5, course.getLastApplicationDate());
		preparedStatement.setURL(6, course.getCoursePlan());
		preparedStatement.setURL(7,  course.getSchedule());
		
		
		} catch (SQLException e) {
		//Här skapar vi ett felmeddelande där en ruta kommer upp och informerar att det inte gick att spara.
			e.printStackTrace();
		}
	}

	@Override
	public Course loadCourse(String courseCode) throws NoSuchElementException{
		Course course = null;
		try {
			ResultSet resultSet = dbConManagerSingleton.executeQuery("SELECT * FROM "
					+ "Course WHERE courseID =" + courseCode);
		if(!resultSet.next()) {
			throw new NoSuchElementException("Kursen du söker, finns tyvärr inte ");
		} else {
			course = new Course(resultSet.getString(1), resultSet.getString(3), resultSet.getString(4),
					 resultSet.getString(5), resultSet.getString(6));
			dbConManagerSingleton.close();
		} 
	}	catch(SQLException e) {
			System.out.println("Något gick fel, gick inte att hämta kurs");
		}
		return course;
		}
	
	public List<Course> loadAllCourses(){
		
		ArrayList<Course> listAllCourses = new ArrayList<>();
		
		try {
			ResultSet resultSet = dbConManagerSingleton.executeQuery("SELECT * from Course");
			while(resultSet.next()) {
				listAllCourses.add(new Course(resultSet.getString(1), resultSet.getString(2), 
						resultSet.getString(3), resultSet.getString(4), resultSet.getString(5)));
				dbConManagerSingleton.close();
			} 
		} catch(SQLException e) {
			System.out.println("Finns inga kurser att visa!");
		}
		return null;
	}
	
	public void updateCourse(String courseCode, String courseName, 
			String applicationCode, String courseSpeed, String coursePoints, 
			String lastApplicationDate, URL coursePlan, URL schedule, char courseGrade) {
		
		Course theUpdatedCourse = null;
		theUpdatedCourse = loadCourse(courseCode);	
		
		theUpdatedCourse.setCourseCode(courseCode);
		theUpdatedCourse.setCourseName(courseName);
		theUpdatedCourse.setApplicationCode(applicationCode);
		theUpdatedCourse.setCourseSpeed(courseSpeed);
		theUpdatedCourse.setCoursePoints(coursePoints);
		theUpdatedCourse.setLastApplicationDate(lastApplicationDate);
		theUpdatedCourse.setCoursePlan(coursePlan);
		theUpdatedCourse.setSchedule(schedule);
		theUpdatedCourse.setCourseGrade(courseGrade);
			
		updateCourse(theUpdatedCourse);
	}

	@Override
	public void updateCourse(Course course) {
		// TODO Auto-generated method stub
		
	}

}
