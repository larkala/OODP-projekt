package control;

import java.net.URL;

import dao.CourseDAO;

public class EditCourseManager {
	
	public static void updateCourse(String courseCode, String courseName, String applicationCode, 
			String courseSpeed, String coursePoints, String lastApplicationDate, URL coursePlan, URL schedule, char courseGrade) {
		
		CourseDAO update = new CourseDAO();
		update.updateCourse(courseCode, courseName, applicationCode, courseSpeed, coursePoints, lastApplicationDate, coursePlan, schedule, courseGrade);
	}


////???//////
	public static void updateCourse(String courseName, String applicationCode, String courseSpeed, String coursePoints,
			String lastApplicationDate, String coursePlan, String schedule, String courseGrade) {
		// TODO Auto-generated method stub
		
	}
	
}
