package model;

public class Project implements CourseMoment{

	private String projectName;
	private int projectGroup;
	private char projectGrade;
	private String lastDateForProject;
	private String projectAttender;

	////////////// SETTERS////////////////////////////////////////////
	public void setProjectName(String projectName) {this.projectName = projectName;}
	public void setProjectGroup(int projectGroup) {this.projectGroup = projectGroup;}
	public void setProjectGrade(char projectGrade) {this.projectGrade = projectGrade;}
	public void setLastDateForProject(String lastDateForProject) {this.lastDateForProject = lastDateForProject;}
	public void setProjectAttender(String projectAttender) {this.projectAttender = projectAttender;}

	////////////// GETTERS////////////////////////////////////////////
	public String getProjectName() {return projectName;}
	public int getProjectGroup() {return projectGroup;}
	public char getProjectGrade() {return projectGrade;}
	public String getLastDateForProject() {return lastDateForProject;}
	public String getProjectAttender() {return projectAttender;}

}
