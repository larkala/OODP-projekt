package view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import control.EditCourseManager;

public class EditCoursePanel extends CreateCoursePanel{
	
		public EditCoursePanel() {
			super();
		}
		
		@Override
		protected void addMiniPanels() {
			JPanel[] panels = {courseNamePanel,coursePointsPanel, courseSpeedPanel,applicationCodePanel,courseGradePanel,lastApplicationDatePanel,schedulePanel,coursePlanPanel};

	        setLayout(new GridBagLayout());
	        GridBagConstraints gbc = new GridBagConstraints();
	        gbc.fill = GridBagConstraints.HORIZONTAL;
	        gbc.gridx = 0;
	        gbc.gridheight = 1;
	        gbc.insets = new Insets(10, 0, 0, 0);
	        
	        for (int i = 0; i < panels.length; i++) {
	        	gbc.gridy = i;
	        	add(panels[i],gbc);
			}
		}
			
		public class UpdateCourseListener implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {

			if(courseCodeField.getText().length() > 0 
				&&	courseNameField.getText().length() > 0 
				&& applicationCodeField.getText().length() > 0	
			    && courseSpeedField.getSelectedItem() != null
		        && coursePointsField.getSelectedItem() != null
			    && lastApplicationDateField.getDate() != null
		        && coursePlanField.getText().length() > 0
			    && scheduleField.getText().length() > 0
			    && courseGradeField.getSelectedItem() != null) {
					
				String courseCode = courseCodeField.getText();
				String courseName = courseNameField.getText();
				String coursePlan = coursePlanField.getText();
				String applicationCode = applicationCodeField.getText();
				String schedule = scheduleField.getText();
				String lastApplicationDate = lastApplicationDateField.getDateFormatString();
				String coursePoints = coursePointsField.getActionCommand().toString();
				String courseSpeed = courseSpeedField.getActionCommand().toString();
				String courseGrade = courseGradeField.getActionCommand().toString();
					
					
				callEditCourse(courseCode, courseName, applicationCode, courseSpeed, coursePoints, lastApplicationDate, coursePlan, schedule, courseGrade);
					
				}else {
					System.out.println("Samtliga fält måste fyllas i!");
				}
			}

			private void callEditCourse(String courseCode, String courseName, String applicationCode, String courseSpeed,
				String coursePoints, String lastApplicationDate, String coursePlan, String schedule,
				String courseGrade) {
				try {
					EditCourseManager.updateCourse(courseName, applicationCode, courseSpeed, coursePoints, 
							lastApplicationDate, coursePlan, schedule, courseGrade);
				}catch(Exception f) {
					System.out.println("Gick inte att uppdatera kursen!");
				}
			}		
	}
}


