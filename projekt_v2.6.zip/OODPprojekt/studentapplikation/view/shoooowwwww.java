package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;


///Testkod för showCoursePanel///////////////////////////
public class shoooowwwww{
	
	public static void main(String[] args) {
		JFrame f = new JFrame();
		JPanel e = new showCoursePanel();
		f.add(e);
		f.setBounds(500, 500, 500, 500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
}
