package model;

import java.util.ArrayList;
import java.util.List;

public class Group {
	
	private List<Student> groupMembers = new ArrayList<>();
	private String groupName;
	private Course course;
	private CourseMoment moment;
	
	public Group(String name, Course course, CourseMoment moment) {
		this.groupName = name;
		this.course = course;
		this.moment = moment;
	}
	
	public void addStudent(Student student) {groupMembers.add(student);}
	public int getGroupSize() {return groupMembers.size();}
	public void removeStudent(Student student) {groupMembers.remove(student);}

	//getters
	public String getGroupName() {return groupName;}
	public Course getCourse() {return course;}
	public CourseMoment getMoment() {return moment;}
	public String getGroupMembers() {
		String allNames = "";
		for(Student student: groupMembers) {
			allNames += student.getName() + ", ";
		}
		return allNames.substring(0,allNames.length()-3);
	}
}
