package model;

import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Course {
				
	private String courseCode;
	private String courseName;
	private String applicationCode;
	private String courseSpeed;
	private String coursePoints;
	private String lastApplicationDate;
	private URL coursePlan;
	private URL schedule;
	private char courseGrade;
	
	private List<CourseMoment> courseMoments = new ArrayList<>();
	
	public Course(String courseCode, String name, String applicationCode, String studySpeed, String uniPoints) {
		this.courseName = name;
		this.courseCode = courseCode;
		this.applicationCode = applicationCode;
		this.courseSpeed = studySpeed;
		this.coursePoints = uniPoints;
		System.out.println(this.courseCode);
		System.out.println(this.courseName);
		System.out.println(this.coursePoints);
		System.out.println(this.applicationCode);
		System.out.println(this.courseSpeed);
		
	}

	//getters
	public String getLastApplicationDate() {return lastApplicationDate;}
	public URL getCoursePlan() {return coursePlan;}	
	public URL getSchedule() {return schedule;}
	public String getCourseCode() {return courseCode;}
	public String getApplicationCode() {return applicationCode;}
	public String getStudySpeed() {return courseSpeed;}
	public String getUniversityPoints() {return coursePoints;}
	public char getCourseGrade() {return courseGrade;}
	public String getCourseName() {return courseName;}

	//setters
	public void setCoursePlan(URI coursePlan) {this.coursePlan = null;
	System.out.println(this.coursePlan);}
	public void setSchedule(URI schema) {this.schedule = null;
	System.out.println(this.schedule);}
	public void setCourseGrade(char grade) {this.courseGrade = grade;
	System.out.println(this.courseGrade);}
	public void setLastApplicationDate(String lastApplicationDate) {this.lastApplicationDate = lastApplicationDate;
	System.out.println(this.lastApplicationDate);}

	public void addCourseMoment(CourseMoment moment) {
		courseMoments.add(moment);
	}

}
