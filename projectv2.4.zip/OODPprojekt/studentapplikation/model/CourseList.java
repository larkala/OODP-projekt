package model;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CourseList {
	
	private SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	private List<Course> courses = new ArrayList<>();
	
	public void addCourse(String courseCode, String name, String applicationCode, String uniPoints, String studySpeed, String courseGrade, Date lastAppDate, URI schema, URI coursePlan) {
		Course currentCourse = new Course(courseCode, name, applicationCode, studySpeed, uniPoints);
		currentCourse.setCourseGrade(courseGrade.charAt(0));
		currentCourse.setLastApplicationDate(df.format(lastAppDate));
		currentCourse.setSchedule(schema);
		currentCourse.setCoursePlan(coursePlan);
		
		courses.add(currentCourse);
	}
	
	
	
}
