package model;

public interface CourseMoment {
	
	
}
