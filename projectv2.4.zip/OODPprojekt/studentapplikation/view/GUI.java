package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import control.CourseManager;

public class GUI extends JFrame{
	
	CourseManager manager = new CourseManager();
	
	JPanel addPanel, viewPanel;
	JButton saveCourseButton = new JButton("Spara");
	Font rubrik = new Font(Font.SANS_SERIF, Font.BOLD, 22);
	JLabel titel1 = new JLabel("Lägg till kurser");
	JLabel titel2 = new JLabel("Skapade kurser");
	CoursePanel c;
	showCoursePanel a;
	
	public GUI(){
		setLayout(new GridLayout(2, 1));
		
		createComponents();
		
		setBounds(500,500,500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void createComponents() {
		addPanel = new JPanel();
		viewPanel = new JPanel();
		viewPanel.setBackground(Color.white);
		
		c = new CoursePanel();
		a = new showCoursePanel();
		
		addPanel.setLayout(new BorderLayout());
		addPanel.add(c, BorderLayout.CENTER);
		addPanel.add(titel1, BorderLayout.NORTH);
		addPanel.add(saveCourseButton, BorderLayout.SOUTH);
		
		ActionListener listener = new AddListener();
		saveCourseButton.addActionListener(listener);
		
		titel1.setFont(rubrik);
		
		viewPanel.setLayout(new BorderLayout());
		viewPanel.add(a);
		
		titel2.setFont(rubrik);
		
		
		add(addPanel);
		add(viewPanel);
	}
	
	private class AddListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			
			manager.callAdd(c.getCourseCodeGUI(),c.getCourseNameGUI(), c.getApplicationCodeGUI(),c.getCoursePointsGUI(),c.getCourseSpeedGUI(), c.getCourseGradeGUI(), c.getLastApplicationDateGUI(), c.getScheduleGUI(), c.getCoursePlanGUI());
			
		}
		
	}
	
	public static void main(String[] args) {
		GUI g = new GUI();
	}
}
