package view;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.net.URI;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;

public class CoursePanel extends JPanel {
    
    JPanel applicationCodePanel, courseNamePanel, lastApplicationDatePanel, courseGradePanel, coursePlanPanel, schedulePanel, courseCodePanel, coursePointsPanel, courseSpeedPanel; 
    JLabel applicationCodeLabel, courseNameLabel, lastApplicationDateLabel, courseGradeLabel, coursePlanLabel, scheduleLabel, courseCodeLabel, coursePointsLabel, courseSpeedLabel;
    JTextField applicationCodeField, courseNameField, coursePlanField, scheduleField, courseCodeField;
    JComboBox coursePointsField, courseSpeedField, courseGradeField;
    JDateChooser lastApplicationDateField;
    
    String[] coursePoints = {"7,5 hp", "12 hp", "15 hp", "18 hp", "30 hp"};
    String[] courseSpeeds = {"25%","50%","75%","100%","150%"};
    String[] grades = {"A","B","C","D","E","F"};
    
    public CoursePanel () {
        
    	applicationCodeLabel = new JLabel("Anm�lningskod ");
    	courseNameLabel = new JLabel("Kursnamn: ");
    	lastApplicationDateLabel = new JLabel("Sista Anm�lningsdatum: ");
    	courseGradeLabel = new JLabel("Kursbetyg: ");
    	coursePlanLabel = new JLabel("L�nk till kursplan: ");
    	scheduleLabel = new JLabel("L�nk till kursschema: ");
    	courseCodeLabel = new JLabel("Kurskod: ");
    	courseSpeedLabel = new JLabel("Kursfart: ");
    	coursePointsLabel = new JLabel("H�gskolepo�ng: ");
    	
    	
        applicationCodeField = new JTextField();
        courseNameField = new JTextField();
        coursePlanField = new JTextField("http://");
        scheduleField = new JTextField("http://");
        courseCodeField = new JTextField();
        lastApplicationDateField = new JDateChooser();
        coursePointsField = new JComboBox<>(coursePoints);
        courseSpeedField = new JComboBox<>(courseSpeeds);
        courseGradeField = new JComboBox<>(grades);
        
        
        applicationCodePanel = new JPanel();
        courseNamePanel = new JPanel();
        lastApplicationDatePanel = new JPanel();
        courseGradePanel = new JPanel();
        coursePlanPanel = new JPanel();
        schedulePanel = new JPanel();
        courseCodePanel = new JPanel();
        coursePointsPanel = new JPanel();
        courseSpeedPanel = new JPanel();
        
        applicationCodePanel.setLayout(new GridLayout(1, 2));
        courseNamePanel.setLayout(new GridLayout(1, 2));
        lastApplicationDatePanel.setLayout(new GridLayout(1, 2));
        courseGradePanel.setLayout(new GridLayout(1, 2));
        coursePlanPanel.setLayout(new GridLayout(1, 2));
        schedulePanel.setLayout(new GridLayout(1, 2));
        courseCodePanel.setLayout(new GridLayout(1, 2));
        coursePointsPanel.setLayout(new GridLayout(1, 2));
        courseSpeedPanel.setLayout(new GridLayout(1, 2));
        
        courseCodePanel.add(courseCodeLabel);
        courseCodePanel.add(courseCodeField);
        courseNamePanel.add(courseNameLabel);
        courseNamePanel.add(courseNameField);
        coursePointsPanel.add(coursePointsLabel);
        coursePointsPanel.add(coursePointsField);
        courseSpeedPanel.add(courseSpeedLabel);
        courseSpeedPanel.add(courseSpeedField);
        applicationCodePanel.add(applicationCodeLabel);
        applicationCodePanel.add(applicationCodeField);
        courseGradePanel.add(courseGradeLabel);
        courseGradePanel.add(courseGradeField);
        lastApplicationDatePanel.add(lastApplicationDateLabel);
        lastApplicationDatePanel.add(lastApplicationDateField);
        schedulePanel.add(scheduleLabel);
        schedulePanel.add(scheduleField);
        coursePlanPanel.add(coursePlanLabel);
        coursePlanPanel.add(coursePlanField);
        
        coursePointsField.setBackground(Color.WHITE);
        courseSpeedField.setBackground(Color.WHITE); 
        courseGradeField.setBackground(Color.WHITE);
        
        JPanel[] panels = {courseCodePanel, courseNamePanel,coursePointsPanel, courseSpeedPanel,applicationCodePanel,courseGradePanel,lastApplicationDatePanel,schedulePanel,coursePlanPanel};

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridheight = 1;
        gbc.insets = new Insets(10, 0, 0, 0);
        
        for (int i = 0; i < panels.length; i++) {
        	gbc.gridy = i;
        	add(panels[i],gbc);
		}

        
    }
    
    public String getCourseCodeGUI() {
    	return this.courseCodeField.getText();
    }
    public String getCourseNameGUI() {
    	return this.courseNameField.getText();
    }
    public String getCoursePointsGUI() {
    	return this.coursePointsField.getSelectedItem().toString();
    	
    }
    public String getCourseSpeedGUI() {
    	return this.courseSpeedField.getSelectedItem().toString();
    }
    public String getApplicationCodeGUI() {
    	return this.applicationCodeField.getText();
    }
    public String getCourseGradeGUI() {
    	return this.courseGradeField.getSelectedItem().toString();
    }
    public Date getLastApplicationDateGUI() {
    	return this.lastApplicationDateField.getDate();
    }
    public URI getScheduleGUI() {
    	URI uri = URI.create(this.scheduleField.getText());
    	return uri ;
    }
    public URI getCoursePlanGUI() {
    	URI uri = URI.create(this.coursePlanField.getText());
    	return uri;
    }
    
}

