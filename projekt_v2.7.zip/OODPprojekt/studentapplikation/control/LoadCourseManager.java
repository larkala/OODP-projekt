package control;

import java.util.List;

import dao.CourseDAO;
import model.Course;

public class LoadCourseManager {
	
	public static String loadCourse(String courseCode) {
		CourseDAO restoreCourse = new CourseDAO();
		Course loadCourse = restoreCourse.loadCourse(courseCode);
		String CourseString = loadCourse.toString();
		return CourseString;
		
	}
	
	public List<Course> loadAllCourses(){
		CourseDAO restoreCourses = new CourseDAO();
		List<Course> loadCourses = restoreCourses.loadAllCourses();
		////??? lite oklart.. 
		return loadCourses;
		
	}
    
}









