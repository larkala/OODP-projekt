package control;

import dao.CourseDAO;

public class EditCourseManager {

	public void updateCourse(String courseCode, String courseName, String applicationDate,
			String courseSpeed, String coursePoints, String lastApplicationDate, String coursePlan, String schedule, String courseGrade) {
		CourseDAO update = new CourseDAO();
		update.updateCourse(courseCode, courseName, applicationDate, courseSpeed, coursePoints, lastApplicationDate, coursePlan, schedule, courseGrade);
	}
}
