package control;

import java.net.URI;
import java.net.URL;
import java.util.Date;
import model.CourseList;

public class AddCourseManager {

	CourseList model = new CourseList();
	
	public void saveCourse(String courseCode, String CourseName, String applicationCode, String CoursePoints, String CourseSpeed, String courseGrade, String lastApplicationDate, String schedule, String coursePlan){
		model.addCourse(courseCode, CourseName, applicationCode, CoursePoints, CourseSpeed, courseGrade, lastApplicationDate, schedule, coursePlan);
	}

	public void callAdd(String courseCodeGUI, String courseNameGUI, String applicationCodeGUI, String coursePointsGUI,
			String courseSpeedGUI, String courseGradeGUI, Date lastApplicationDateGUI, URI scheduleGUI,
			URI coursePlanGUI) {
		// TODO Auto-generated method stub
		
	}
	
}
