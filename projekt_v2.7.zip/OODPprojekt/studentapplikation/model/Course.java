package model;

import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Course {
				
	private String courseCode;
	private String courseName;
	private String applicationCode;
	private String courseSpeed;
	private String coursePoints;
	private String lastApplicationDate;
	private String coursePlan;
	private String schedule;
	private String courseGrade;
	
	private List<CourseMoment> courseMoments = new ArrayList<>();
	
	public Course(String courseCode, String name, String applicationCode, String studySpeed, String uniPoints) {
		this.courseName = name;
		this.courseCode = courseCode;
		this.applicationCode = applicationCode;
		this.courseSpeed = studySpeed;
		this.coursePoints = uniPoints;
		System.out.println(this.courseCode);
		System.out.println(this.courseName);
		System.out.println(this.coursePoints);
		System.out.println(this.applicationCode);
		System.out.println(this.courseSpeed);
		
	}

	//getters
	public String getLastApplicationDate() {return lastApplicationDate;}
	public String getCoursePlan() {return coursePlan;}	
	public String getSchedule() {return schedule;}
	public String getCourseCode() {return courseCode;}
	public String getApplicationCode() {return applicationCode;}
	public String getCourseSpeed() {return courseSpeed;}
	public String getCoursePoints() {return coursePoints;}
	public String getCourseGrade() {return courseGrade;}
	public String getCourseName() {return courseName;}

	//setters

	public void setCourseCode(String courseCode) {this.courseCode = courseCode;}
	public void setCourseName(String courseName) {this.courseName = courseName;}
	public void setApplicationCode(String applicationCode) {this.applicationCode = applicationCode;}
	public void setCourseSpeed(String courseSpeed) {this.courseSpeed = courseSpeed;}
	public void setCoursePoints(String coursePoints) {this.coursePoints = coursePoints;}
	public void setCoursePlan(String  coursePlan) {this.coursePlan = null;
	System.out.println(this.coursePlan);}
	public void setSchedule(String schedule) {this.schedule = null;
	System.out.println(this.schedule);}
	public void setCourseGrade(String grade) {this.courseGrade = grade;
	System.out.println(this.courseGrade);}
	public void setLastApplicationDate(String lastApplicationDate) {this.lastApplicationDate = lastApplicationDate;
	System.out.println(this.lastApplicationDate);}

	public void addCourseMoment(CourseMoment moment) {
		courseMoments.add(moment);
	}

}
