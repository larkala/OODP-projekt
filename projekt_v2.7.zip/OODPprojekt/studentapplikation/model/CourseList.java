package model;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CourseList {
	
	private SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	private List<Course> courses = new ArrayList<>();
	
	public void addCourse(String courseCode, String name, String applicationCode, String uniPoints, String studySpeed, String courseGrade, String lastAppDate, String schedule, String coursePlan) {
		Course currentCourse = new Course(courseCode, name, applicationCode, studySpeed, uniPoints);
		currentCourse.setCourseGrade(courseGrade);
		currentCourse.setLastApplicationDate(df.format(lastAppDate));
		currentCourse.setSchedule(schedule);
		currentCourse.setCoursePlan(coursePlan);
		
		courses.add(currentCourse);
	}		
}
