package model;

public class Student {
	private String firstName, lastName;
	private int persnbr;
	private String email;
	private String adress;
	
	public Student (String fname, String lname, String email, String adress, int persnr) {
		this.firstName = fname;
		this.lastName = lname;
		this.email = email;
		this.adress = adress;
		this.persnbr = persnr;
	}

	public String getName() {return (firstName + " " + lastName);}
	public int getPersnbr() {return persnbr;}
	public String getEmail() {return email;}
	public String getAdress() {return adress;}
		
}
