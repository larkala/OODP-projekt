package dao;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import db.DbConManagerSingleton;
import model.Course;

public class CourseDAO implements IDao{
	
	DbConManagerSingleton dbConManagerSingleton = null;
	
	public CourseDAO() {
		dbConManagerSingleton = DbConManagerSingleton.getInstance();
	}

	@Override
	public void saveCourse(Course course) {
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int countingRows = 0;
		
		try {
		preparedStatement = dbConManagerSingleton.preparedStatement("INSERT INTO..");
		preparedStatement.setString(0, course.getCourseCode());
		preparedStatement.setString(1, course.getCourseName());
		preparedStatement.setString(2, course.getApplicationCode());
		preparedStatement.setString(3, course.getStudySpeed());
		preparedStatement.setString(4, course.getUniversityPoints());
		preparedStatement.setString(5, course.getLastApplicationDate());
		preparedStatement.setURL(6, course.getCoursePlan());
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Course loadCourse(String courseID) throws NoSuchElementException{
		Course course = null;
		try {
			ResultSet resultSet = dbConManagerSingleton.executeQuery("SELECT * FROM "
					+ "Course WHERE courseID =" + courseID);
		if(!resultSet.next()) {
			throw new NoSuchElementException("The course you're looking for, doesn't exist! ");
		} else {
			course = new Course(resultSet.getString(1), resultSet.getString(3), resultSet.getString(4),
					 resultSet.getString(5), resultSet.getString(6));
			dbConManagerSingleton.close();
		} 
	}	catch(SQLException e) {
			System.out.println("....");
		}
		return course;
		}
	
	public List<Course> loadAllCourses(){
		
		ArrayList<Course> listAllCourses = new ArrayList<>();
		
		try {
			ResultSet resultSet = dbConManagerSingleton.executeQuery("SELECT * from Course");
			while(resultSet.next()) {
				listAllCourses.add(new Course(resultSet.getString(1), resultSet.getString(2), 
						resultSet.getString(3), resultSet.getString(4), resultSet.getString(5)));
				dbConManagerSingleton.close();
			} 
		} catch(SQLException e) {
			System.out.println("...");
		}
		return null;
	}
	
	@Override
	public void updateCourse(Course course) {
		// TODO Auto-generated method stub
		
	}

}
