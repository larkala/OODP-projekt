package dao;
import java.util.List;
import model.Course;

public interface IDao {
	
	public void saveCourse(Course course);
	public Course loadCourse(String courseCode);
	public void updateCourse(Course course);
	public List<Course> loadAllCourses();
	
}
