package view;

import javax.swing.JFrame;

public class ComponentViewerTester {
public static void main(String[] args) {

	JFrame f = new CourseMomentFrame();
	f.setVisible(true);
	f.setBounds(500, 500, 500, 500);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}
