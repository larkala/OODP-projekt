package view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JPanel;

public class EditCoursePanel extends CreateCoursePanel{

	public EditCoursePanel() {
		super();
	}
	
	@Override
	protected void addMiniPanels() {
		JPanel[] panels = {courseNamePanel,coursePointsPanel, courseSpeedPanel,applicationCodePanel,courseGradePanel,lastApplicationDatePanel,schedulePanel,coursePlanPanel};

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridheight = 1;
        gbc.insets = new Insets(10, 0, 0, 0);
        
        for (int i = 0; i < panels.length; i++) {
        	gbc.gridy = i;
        	add(panels[i],gbc);
		}
	}

}
