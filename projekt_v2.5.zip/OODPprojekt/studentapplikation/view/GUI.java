package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


import view.CreateCoursePanel;
import control.CourseManager;

public class GUI extends JFrame{
	
	CourseManager manager = new CourseManager();
	
	JPanel addPanel, viewPanel;
	JButton saveCourseButton = new JButton("Spara");
	Font rubrik = new Font(Font.SANS_SERIF, Font.BOLD, 22);
	JLabel titel1 = new JLabel();
	JLabel titel2 = new JLabel();
	CreateCoursePanel c;
	ShowCoursePanel s;
	GridBagConstraints gbc = new GridBagConstraints();
	
	public GUI(){
		setLayout(new GridBagLayout());
		createComponents();
		
		setBounds(500,500,500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void createComponents() {
		addPanel = new JPanel();
		viewPanel = new JPanel();
		
		c = new CreateCoursePanel();
		s = new ShowCoursePanel();	
		
		titel1.setText("L�gg till kurs");
		addPanel.setLayout(new GridBagLayout());
		gbc.gridx = 0;
		gbc.gridy = 0;
		addPanel.add(titel1, gbc);
		gbc.gridy = 1;
		addPanel.add(c, gbc);
		gbc.gridy = 2;
		addPanel.add(saveCourseButton, gbc);
		
		titel2.setText("Visa kurs");
		viewPanel.setLayout(new GridBagLayout());
		
		viewPanel.add(s);
		viewPanel.add(titel2, BorderLayout.NORTH);
		
		ActionListener listener = new AddListener();
		saveCourseButton.addActionListener(listener);
		

		titel1.setFont(rubrik);
		titel2.setFont(rubrik);
		
		gbc.gridy = 0;
		add(addPanel, gbc);
		gbc.gridy = 1;
		add(viewPanel, gbc);
	}

	private class AddListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			manager.callAdd(c.getCourseCodeGUI(),c.getCourseNameGUI(), c.getApplicationCodeGUI(),c.getCoursePointsGUI(),c.getCourseSpeedGUI(), c.getCourseGradeGUI(), c.getLastApplicationDateGUI(), c.getScheduleGUI(), c.getCoursePlanGUI());
			
		}
		
	}
	
	public static void main(String[] args) {
		GUI g = new GUI();
	}
	
	
}
